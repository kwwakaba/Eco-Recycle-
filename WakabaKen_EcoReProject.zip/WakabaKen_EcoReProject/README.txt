Eco-Recycle-System-in-Java
Ken Wakaba

Recycle Monitoring System that monitors a group recycling machines, and enables the administrator to control and check the status of each recycling machine.
Designed and developed user-friendly interface using Java Swing components

TO RUN:
click on Java EXE file.

Files:
TotalPrice: file with total price of RCM written in everytime receipt button is pressed
TotalWeight1/2: files with total weight of RCM 1 and 2 written in everytime machine is emptied
RCM 1/2: files with date stamp of when RCM 1 and 2 are emptied written in everytime empty button is presed 


src: Contains source code
doc: contains java doc of project
CRC and Diagrams: contain the CRC cards and class/interaction.package diagrams